// stats.js — lightweight system stats for the /api/stats endpoint
// Uses only Node built-ins, no extra dependencies

import { readFileSync } from "fs";
import { cpus, totalmem, freemem, uptime } from "os";

function getCPU() {
  const cpuList = cpus();
  // Sample CPU usage over 100ms
  return new Promise((resolve) => {
    const start = cpuList.map(c => ({ ...c.times }));
    setTimeout(() => {
      const end = cpus();
      let totalIdle = 0, totalTick = 0;
      end.forEach((cpu, i) => {
        const s = start[i];
        const e = cpu.times;
        const idle = e.idle - s.idle;
        const total = Object.values(e).reduce((a, b) => a + b, 0) -
                      Object.values(s).reduce((a, b) => a + b, 0);
        totalIdle += idle;
        totalTick += total;
      });
      const used = 100 - Math.round((totalIdle / totalTick) * 100);
      resolve(Math.max(0, Math.min(100, used)));
    }, 100);
  });
}

export async function getStats() {
  const cpu = await getCPU();
  const total = totalmem();
  const free = freemem();
  const ram = Math.round(((total - free) / total) * 100);

  // Try to get disk usage on Linux
  let disk = null;
  try {
    const stat = readFileSync("/proc/mounts", "utf8");
    // rough approximation — real disk stat needs statvfs which needs native addon
    disk = null; // placeholder — implement with `df` child_process if needed
  } catch {}

  return {
    cpu,
    ram,
    disk,
    uptime: Math.floor(uptime()),
    memTotal: Math.round(total / 1024 / 1024),
    memFree: Math.round(free / 1024 / 1024)
  };
}
