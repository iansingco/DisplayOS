import { resolveWidget } from "../widgets/index.js";
const COLS = 12, ROWS = 8;
export function WidgetTile({ widget, containerWidth, containerHeight }) {
  const entry = resolveWidget(widget.type);
  if (!entry) return null;
  const { component: Component } = entry;
  const cellW = containerWidth / COLS, cellH = containerHeight / ROWS;
  return (
    <div style={{ position:"absolute", left:widget.x*cellW, top:widget.y*cellH, width:widget.w*cellW, height:widget.h*cellH, overflow:"hidden", borderRadius:"8px", background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)", backdropFilter:"blur(2px)" }}>
      <Component config={widget.config ?? {}} />
    </div>
  );
}
